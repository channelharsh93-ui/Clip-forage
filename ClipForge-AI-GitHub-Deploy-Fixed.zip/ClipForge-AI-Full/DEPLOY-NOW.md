# ClipForge deployment — corrected

The project structure is intentionally preserved:

- `frontend/` = Vite/React app
- `backend/` = FastAPI video-processing API

## Vercel

Use the repository root **without changing Root Directory**.

Build settings:
- Install: `npm --prefix frontend install`
- Build: `npm --prefix frontend run build`
- Output: `frontend/dist`
- Framework: Vite

Recommended environment variable:
`VITE_API_BASE_URL=https://YOUR-BACKEND-DOMAIN`

The backend must be deployed separately on a persistent Python host. Vercel is only the frontend.

## Netlify

The included `netlify.toml` sets:
- Base: `frontend`
- Build: `npm run build`
- Publish: `dist`

Do not set the publish directory to `frontend/dist` while the base is `frontend`.

## GitHub

Do not flatten the project. The repository must contain:
`frontend/src/main.tsx`

If `src/main.tsx` is missing at the repository root, that is expected. It belongs at:
`frontend/src/main.tsx`
